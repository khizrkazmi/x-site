<?php

// Function to get all available verse indices from the CSV
function getAvailableVerses() {
    $verseFile = 'en_selected_verses.txt';
    $availableVerses = [];

    if (($handle = fopen($verseFile, "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            // Assuming the verse number is in the first column
            $availableVerses[] = (int) $data[0]; // Store the verse index
        }
        fclose($handle);
    }

    return $availableVerses;
}

// Function to load the verse of the day
function getVerseOfTheDay() {
    $verseFile = 'today_verse.txt';
    $currentDate = date('Y-m-d');
    
    // Check if today's verse is already stored
    if (file_exists($verseFile)) {
        $fileData = file_get_contents($verseFile);
        list($storedDate, $storedVerseIndex) = explode('|', $fileData);
        
        if ($storedDate == $currentDate) {
            return (int) $storedVerseIndex;
        }
    }

    // If no valid data is found, get a new verse
    $verseIndex = getRandomVerseIndex();

    // Save today's verse in the file
    file_put_contents($verseFile, $currentDate . '|' . $verseIndex);

    return $verseIndex;
}

// Function to get a random verse index from available verses
function getRandomVerseIndex() {
    $availableVerses = getAvailableVerses();
    if (!empty($availableVerses)) {
        // Pick a random index from available verses
        return $availableVerses[array_rand($availableVerses)];
    }
    return null; // In case no verses are available
}

// Function to load verse details from the CSV files
function getVerseDetails($verseIndex) {
    if ($verseIndex === null) {
        return null;
    }

    // CSV file paths for Arabic and translations
    $arabicFile = 'en_selected_verses.txt';
    $pickthallFile = 'data/en_pickthall.txt';
    $sahihFile = 'data/en_sahih.txt';
    $yusufAliFile = 'data/en_yusufali.txt';
    
    // Fetch the verse details from each CSV
    $arabicData = getCsvData($arabicFile, $verseIndex);
    $pickthallData = getCsvData($pickthallFile, $verseIndex);
    $sahihData = getCsvData($sahihFile, $verseIndex);
    $yusufAliData = getCsvData($yusufAliFile, $verseIndex);
    
    return [
        'arabic' => $arabicData,
        'pickthall' => $pickthallData,
        'sahih' => $sahihData,
        'yusufali' => $yusufAliData
    ];
}

// Helper function to get data from CSV by verse index
function getCsvData($csvFile, $verseIndex) {
    if (($handle = fopen($csvFile, "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if ((int) $data[0] == $verseIndex) {
                fclose($handle);
                return $data[3]; // Assuming the verse text is in the 4th column (index 3)
            }
        }
        fclose($handle);
    }
    return null;
}

// Get the verse of the day
$verseIndex = getVerseOfTheDay();
$verseDetails = getVerseDetails($verseIndex);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quran Verse of the Day</title>
    <style>
        body {
            background-image: url('data/background5.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #fff;
        }
        .verse-container {
            border-radius: 15px;
            padding: 30px 50px;
            max-width: 800px;
            text-align: center;
            margin: 20px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
        }
        h3 {
            font-family: 'Scheherazade New', serif;
            font-size: 2.5rem;
            color: #ffd700;
            margin-bottom: 20px;
        }
        .arabic {
            font-family: 'Amiri', serif;
            font-size: 2rem;
            color: #fff;
            direction: rtl;
            margin-bottom: 40px;
            line-height: 1.8;
        }
        .translation {
            font-family: 'Georgia', serif;
            font-size: 1.2rem;
            color: #e0e0e0;
            margin-bottom: 20px;
            line-height: 1.6;
        }
        .translation strong {
            color: #ffd700;
            font-weight: bold;
        }
        .separator {
            margin: 20px 0;
            height: 2px;
            background-color: #ffd700;
        }
        footer {
            font-size: 0.9rem;
            color: #ccc;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="verse-container">
        <h3>Quran Verse of the Day (Verse #<?= $verseIndex ?>)</h3>

        <div class="arabic">
            <?= htmlspecialchars($verseDetails['arabic']) ?>
        </div>

        <div class="separator"></div>

        <div class="translation">
            <strong>Pickthall:</strong> <?= htmlspecialchars($verseDetails['pickthall']) ?>
        </div>

        <div class="translation">
            <strong>Sahih International:</strong> <?= htmlspecialchars($verseDetails['sahih']) ?>
        </div>

        <div class="translation">
            <strong>Yusuf Ali:</strong> <?= htmlspecialchars($verseDetails['yusufali']) ?>
        </div>
    </div>
</body>
</html>
